const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const pool = require('../config/db');
const { generateToken } = require('../config/jwt');

async function login(req, res) {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const cleanEmail = email.trim().toLowerCase();
    const cleanPassword = password.trim();

    // Query user
    const [users] = await pool.query(
      'SELECT * FROM users WHERE email = ? LIMIT 1',
      [cleanEmail]
    );

    if (!users.length) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const user = users[0];

    if (user.status === 'deactivated') {
      return res.status(403).json({ error: 'This account has been deactivated. Please contact your administrator.' });
    }

    // 1. Direct and case-normalized comparison
    let isValid = await bcrypt.compare(cleanPassword, user.password_hash);
    if (!isValid && cleanPassword !== cleanPassword.toUpperCase()) {
      isValid = await bcrypt.compare(cleanPassword.toUpperCase(), user.password_hash);
    }
    if (!isValid && cleanPassword !== cleanPassword.toLowerCase()) {
      isValid = await bcrypt.compare(cleanPassword.toLowerCase(), user.password_hash);
    }

    // 2. Fallback check for default roll numbers or faculty keys
    // STRICT SECURITY RULE: ONLY allowed when first_login_pending is true/1.
    // Once a user has set their own password (first_login_pending = 0), previous defaults are permanently revoked.
    const isFirstLoginPending = user.first_login_pending === 1 || user.first_login_pending === true || user.first_login_pending === '1';
    if (!isValid && isFirstLoginPending) {
      const regNo = cleanEmail.split('@')[0].toUpperCase();
      const phoneDigits = user.phone ? user.phone.replace(/\D/g, '') : '';
      const phoneSuffix = phoneDigits.length >= 4 ? phoneDigits.slice(-4) : null;
      const validDefaults = [];

      if (user.role === 'student') {
        if (regNo) validDefaults.push(regNo);
        if (user.roll_number) validDefaults.push(user.roll_number.toUpperCase());
      }

      if (user.role === 'faculty' && phoneSuffix) {
        validDefaults.push(`MVGRDE@${phoneSuffix}`);
        validDefaults.push(`mvgrde@${phoneSuffix}`);
      }

      const cleanUpper = cleanPassword.toUpperCase();
      const cleanLower = cleanPassword.toLowerCase();

      if (
        validDefaults.some(
          d => d.toUpperCase() === cleanUpper || d.toLowerCase() === cleanLower
        )
      ) {
        isValid = true;
        const newHash = await bcrypt.hash(cleanPassword, 10);
        await pool.query('UPDATE users SET password_hash = ? WHERE id = ?', [newHash, user.id]);
      }
    }

    if (!isValid) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const tokenPayload = {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      branch: user.branch,
      current_semester: user.current_semester,
      section: user.section,
      designation: user.designation,
      roll_number: user.roll_number,
    };

    const token = generateToken(tokenPayload);

    // Set HTTP-Only Cookie
    res.cookie('de_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      path: '/',
    });

    // Record audit event
    await pool.query(
      'INSERT INTO audit_logs (id, action, actor_id, object_id, after_summary) VALUES (?, ?, ?, ?, ?)',
      [
        crypto.randomUUID(),
        'USER_LOGIN',
        user.id,
        user.id,
        JSON.stringify({ ip: req.ip, userAgent: req.headers['user-agent'] })
      ]
    ).catch((e) => console.warn('Audit log write non-fatal notice:', e.message));

    const sanitizedUser = { ...user };
    delete sanitizedUser.password_hash;

    return res.json({
      success: true,
      token,
      user: sanitizedUser,
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Internal server error during login.' });
  }
}

async function me(req, res) {
  return res.json({ user: req.user });
}

async function changePassword(req, res) {
  try {
    const { currentPassword, newPassword } = req.body;
    const userId = req.user.id;

    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters.' });
    }

    // Get current hash
    const [rows] = await pool.query('SELECT password_hash FROM users WHERE id = ? LIMIT 1', [userId]);
    if (!rows.length) {
      return res.status(404).json({ error: 'User not found.' });
    }

    if (currentPassword) {
      const match = await bcrypt.compare(currentPassword, rows[0].password_hash);
      if (!match) {
        return res.status(400).json({ error: 'Current password does not match.' });
      }
    }

    const newHash = await bcrypt.hash(newPassword, 10);
    await pool.query(
      'UPDATE users SET password_hash = ?, first_login_pending = 0, updated_at = NOW() WHERE id = ?',
      [newHash, userId]
    );

    return res.json({ success: true, message: 'Password updated successfully.' });
  } catch (err) {
    console.error('Change password error:', err);
    return res.status(500).json({ error: 'Failed to update password.' });
  }
}

async function logout(req, res) {
  res.clearCookie('de_token', { path: '/' });
  return res.json({ success: true, message: 'Logged out successfully.' });
}

module.exports = {
  login,
  me,
  changePassword,
  logout,
};
